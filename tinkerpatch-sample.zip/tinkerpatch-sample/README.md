# TinkerPatch SDK Sample

[![Build Status](https://travis-ci.org/TinkerPatch/tinkerpatch-sample.svg?branch=master)](https://travis-ci.org/TinkerPatch/tinkerpatch-sample)
[![Download](https://api.bintray.com/packages/simsun/maven/tinkerpatch-android-sdk/images/download.svg) ](https://bintray.com/simsun/maven/tinkerpatch-android-sdk/_latestVersion)
[![Join Slack](https://slack.tinkerpatch.com/badge.svg)](https://slack.tinkerpatch.com)

[相关文档](http://tinkerpatch.com/Docs/intro)
